function NGC = Ngravity_model(A)
G=graph(A);
eigen_NGC=centrality(G,"eigenvector");
GHC= H_index(A)';
for i=1:size(A,1)
NGC(1,i)=eigen_NGC(i,1)*GHC(1,i);
end
D_NGC=dis(A);
ecc = max(D_NGC.*(D_NGC~=Inf),[],2);
r = min(ecc);
NGH=zeros(1,size(A,1));
NGC=zeros(1,size(A,1));
for k=1:size(A,1)
 for d=1:r
  i=find(D_NGC(k,:)==d);
  NGH(1,d)=(1/power(d,2))*NGC(1,k)*sum(NGC(1,i));
 end
 NGC(1,k)=sum(NGH);
end
end