function HC = H_index(A)
Deg=sum(A,1);
G=graph(A);
H=zeros(size(A,1),1);
for g=1:size(A,1)
 Nei_node = neighbors(G,g)';
 N=zeros(1,size(Nei_node,2));
 
   for n=1:size(Nei_node,2)
     N(1,n)=Deg(1,Nei_node(1,n));
   end

  if size(N,2)==1
      H(g,1)=1;
  else
      k=0;
      for i = min(N):max(N)
         for j=1:size(N,2)
          if N(1,j)>=i
            k=k+1;
          end
         end
        if k>=i
           k=0;
        else 
           H(g,1)=i-1;
           break
       end
      end
  end
end
HC = H;
end

