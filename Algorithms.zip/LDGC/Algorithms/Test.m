% Data=load("data fb-messages.txt");
% m=max(max(Data));
% C=zeros(m);
% for kadj=1:size(Data,1)
%   for i=1:size(C,1)
%     for j=1:size(C,2)
%           if i==Data(kadj,1)&&j==Data(kadj,2)
%            C(i,j)=1;
%            C(j,i)=1;
%           end
%      end
%   end
% end
% A=C;


% GC = Gravity_model(A);
% WGC = WGravity_model(A);
% GGC = GGravity_model(A);
% EGC = EGravity_model(A);
% LGC = LGravity_model(A);


% f2 = @() Gravity_model(A);
% f3 = @() WGravity_model(A);
% f4 = @() GGravity_model(A);
% f5 = @() EGravity_model(A);
% f6 = @() LGravity_model(A);
% 
% t2 = timeit(f2);
% t3 = timeit(f3);
% t4 = timeit(f4);
% t5 = timeit(f5);
% t6 = timeit(f6);
% T=[t2,t3,t4,t5,t6];


Data=load("ia-escorts-dynamic.txt");
s=Data(:,1);
t=Data(:,2);
g=graph(s,t);
plot(g);

    



































