Data=load("data fb-messages.txt");
m=max(max(Data));
C=zeros(m);
for kadj=1:size(Data,1)
  for i=1:size(C,1)
    for j=1:size(C,2)
          if i==Data(kadj,1)&&j==Data(kadj,2)
           C(i,j)=1;
           C(j,i)=1;
          end
     end
  end
end
A=C;
In=zeros(1,6);
ii=lHR([1:5],1);
iii=lHR([6:10],1);
Infected=LHR2(A,ii,iii);
In(1,1)=Infected;

ii=lHR([1:5],2);
iii=lHR([6:10],2);
Infected=LHR2(A,ii,iii);
In(1,2)=Infected;

ii=lHR([1:5],3);
iii=lHR([6:10],3);
Infected=LHR2(A,ii,iii);
In(1,3)=Infected;

ii=lHR([1:5],4);
iii=lHR([6:10],4);
Infected=LHR2(A,ii,iii);
In(1,4)=Infected;

ii=lHR([1:5],5);
iii=lHR([6:10],5);
Infected=LHR2(A,ii,iii);
In(1,5)=Infected;

ii=lHR([1:5],6);
iii=lHR([6:10],6);
Infected=LHR2(A,ii,iii);
In(1,6)=Infected;


