Data=load("dataJazz.txt");
m=max(max(Data));
C=zeros(m);
for k=1:size(Data,1)
  for i=1:size(C,1)
    for j=1:size(C,2)
          if i==Data(k,1)&&j==Data(k,2)
           C(i,j)=1;
           C(j,i)=1;
          end
     end
  end
end
G=graph(C);
figure 
p=plot(G);

% ucc = centrality(G,'degree');
% p.NodeCData = ucc;
% colormap jet
% colorbar
% xticks("auto");
% yticks("auto");
% title('Degree Centrality Scores')
% p.MarkerSize=4;
% hold on
% 
% [a1,B(:,1)]=sort(ucc,'descend');
% ucc(B(1:10),1)=max(ucc);
% ucc(B(11:198),1)=min(ucc);
% p.NodeCData = ucc;




LGC = LGravity_model(C);
ucc = LGC ;
p.NodeCData = ucc;
colormap jet
colorbar
xticks("auto");
yticks("auto");
title('Degree Centrality Scores')
p.MarkerSize=4;
hold on
% p.NodeCData = 1;
[a1,B(:,1)]=sort(ucc,'descend');
ucc(B(1:5),1)=max(ucc);
ucc(B(10:198),1)=min(ucc);
p.NodeCData = ucc;


% figure 
% p=plot(G);
% ucc = centrality(G,'betweenness');
% p.NodeCData = ucc;
% colormap jet
% colorbar
% xticks("auto");
% yticks("auto");
% title('Betweenness Centrality Scores')
% 
% figure 
% p=plot(G);
% ucc = centrality(G,'closeness');
% p.NodeCData = ucc;
% colormap jet
% colorbar
% xticks("auto");
% yticks("auto");
% title('Closeness Centrality Scores')
% 
% figure 
% p=plot(G);
% ucc =  H_index(C);
% p.NodeCData = ucc;
% colormap jet
% colorbar
% xticks("auto");
% yticks("auto");
% title('H-index Centrality Scores')
% 
% figure 
% p=plot(G);
% ucc =  centrality(G,'eigenvector');
% p.NodeCData = ucc;
% colormap jet
% colorbar
% xticks("auto");
% yticks("auto");
% title('Eigenvector Centrality Scores')
% 
% figure 
% p=plot(G);
% GC = Gravity_model(C);
% ucc = GC;
% p.NodeCData = ucc;
% colormap jet
% colorbar
% xticks("auto");
% yticks("auto");
% title('Gravity Centrality Scores')
% 
% 
% figure 
% p=plot(G);
% WGC = WGravity_model(C);
% ucc = WGC';
% p.NodeCData = ucc;
% colormap jet
% colorbar
% xticks("auto");
% yticks("auto");
% title('WGravity Centrality Scores')
% 
% figure 
% p=plot(G);
% GGC = GGravity_model(C);
% ucc = GGC';
% p.NodeCData = ucc;
% colormap jet
% colorbar
% xticks("auto");
% yticks("auto");
% title('GGravity Centrality Scores')
% 
% figure 
% p=plot(G);
% EGC = EGravity_model(C);
% ucc = EGC;
% p.NodeCData = ucc;
% colormap jet
% colorbar
% xticks("auto");
% yticks("auto");
% title('EGravity Centrality Scores')
% 
% figure 
% p=plot(G);
% LGC = LGravity_model(C);
% ucc = LGC;
% p.NodeCData = ucc;
% colormap jet
% colorbar
% xticks("auto");
% yticks("auto");
% title('LGravity Centrality Scores')


