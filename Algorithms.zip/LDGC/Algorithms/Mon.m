Data=load("data insecta-ant-colony1.txt");
m=max(max(Data));
C=zeros(m);
for kadj=1:size(Data,1)
  for i=1:size(C,1)
    for j=1:size(C,2)
          if i==Data(kadj,1)&&j==Data(kadj,2)
           C(i,j)=1;
           C(j,i)=1;
          end
     end
  end
end
A=C;
N=size(A,1);


Graph_DC=graph(A);
Deg_C = centrality(Graph_DC,"degree");

Graph_BC=graph(A);
Betweenness_C = centrality(Graph_BC,"betweenness");

Graph_CC=graph(A);
Closeness_C = centrality(Graph_CC,"closeness");

Graph_EC=graph(A);
Eigen_C = centrality(Graph_CC,"eigenvector");

HC = H_index(A);

GC = Gravity_model(A);

WGC = Gravity_model(A);

GGC = Gravity_model(A);

EGC = Gravity_model(A);

LGC = Gravity_model(A);
Mc=zeros(1,10);

D1=zeros(1,size(A,1));
for i=1:size(A,1)
    for j=1:size(A,1)
        if Deg_C(i)==Deg_C(j)
            D1(1,i)=D1(1,i)+1;
        end
    end
end
I1=0;
for i=1:N
    if D1(1,i)>1
        Ni=(D1(1,i)-1);
        I1=I1+Ni;
    end
end
Mc(1,1)=(1-I1/(N*(N-1)))^2;

D2=zeros(1,size(A,1));
for i=1:size(A,1)
    for j=1:size(A,1)
        if Betweenness_C(i)==Betweenness_C(j)
            D2(1,i)=D2(1,i)+1;
        end
    end
end
I2=0;
for i=1:N
    if D2(1,i)>1
        Ni=(D2(1,i)-1);
        I2=I2+Ni;
    end
end
Mc(1,2)=(1-I2/(N*(N-1)))^2;

D3=zeros(1,size(A,1));
for i=1:size(A,1)
    for j=1:size(A,1)
        if Closeness_C(i)==Closeness_C(j)
            D3(1,i)=D3(1,i)+1;
        end
    end
end
I3=0;
for i=1:N
    if D3(1,i)>1
        Ni=(D3(1,i)-1);
        I3=I3+Ni;
    end
end
Mc(1,3)=(1-I3/(N*(N-1)))^2;

D4=zeros(1,size(A,1));
for i=1:size(A,1)
    for j=1:size(A,1)
        if HC(i)==HC(j)
            D4(1,i)=D4(1,i)+1;
        end
    end
end
I4=0;
for i=1:N
    if D4(1,i)>1
        Ni=(D4(1,i)-1);
        I4=I4+Ni;
    end
end
Mc(1,4)=(1-I4/(N*(N-1)))^2;

D5=zeros(1,size(A,1));
for i=1:size(A,1)
    for j=1:size(A,1)
        if Eigen_C(i)==Eigen_C(j)
            D5(1,i)=D5(1,i)+1;
        end
    end
end
I5=0;
for i=1:N
    if D5(1,i)>1
        Ni=(D5(1,i)-1);
        I5=I5+Ni;
    end
end
Mc(1,5)=(1-I5/(N*(N-1)))^2;

D6=zeros(1,size(A,1));
for i=1:size(A,1)
    for j=1:size(A,1)
        if GC(i)==GC(j)
            D6(1,i)=D6(1,i)+1;
        end
    end
end
I6=0;
for i=1:N
    if D6(1,i)>1
        Ni=(D6(1,i)-1);
        I6=I6+Ni;
    end
end
Mc(1,6)=(1-I6/(N*(N-1)))^2;

D7=zeros(1,size(A,1));
for i=1:size(A,1)
    for j=1:size(A,1)
        if WGC(i)==WGC(j)
            D7(1,i)=D7(1,i)+1;
        end
    end
end
I7=0;
for i=1:N
    if D7(1,i)>1
        Ni=(D7(1,i)-1);
        I7=I7+Ni;
    end
end
Mc(1,7)=(1-I7/(N*(N-1)))^2;

D8=zeros(1,size(A,1));
for i=1:size(A,1)
    for j=1:size(A,1)
        if GGC(i)==GGC(j)
            D8(1,i)=D8(1,i)+1;
        end
    end
end
I8=0;
for i=1:N
    if D8(1,i)>1
        Ni=(D8(1,i)-1);
        I8=I8+Ni;
    end
end
Mc(1,8)=(1-I8/(N*(N-1)))^2;

D9=zeros(1,size(A,1));
for i=1:size(A,1)
    for j=1:size(A,1)
        if EGC(i)==EGC(j)
            D9(1,i)=D9(1,i)+1;
        end
    end
end
I9=0;
for i=1:N
    if D9(1,i)>1
        Ni=(D9(1,i)-1);
        I9=I9+Ni;
    end
end
Mc(1,9)=(1-I9/(N*(N-1)))^2;

D10=zeros(1,size(A,1));
for i=1:size(A,1)
    for j=1:size(A,1)
        if LGC(i)==LGC(j)
            D10(1,i)=D10(1,i)+1;
        end
    end
end
I10=0;
for i=1:N
    if D10(1,i)>1
        Ni=(D10(1,i)-1);
        I10=I10+Ni;
    end
end
Mc(1,10)=(1-I10/(N*(N-1)))^2;

