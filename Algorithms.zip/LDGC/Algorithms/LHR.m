function Infected=LHR(A,ii)

a1=0.002;
a2=0.001;
p1=0.3;
p2=0.1;
v=0.01;
t1=0.05;
t2=0.05;
b1=0.05;
b2=0.01;
TimeStep=1000;
M=size(A,1);
Sta=zeros(TimeStep,M);
L0=zeros(1,size(A,1));
H0=zeros(1,size(A,1));


Sta(1,ii)=2;

k=zeros(1,size(A,1));
l=zeros(1,size(A,1));
h=zeros(1,size(A,1));
k1=zeros(1,size(A,1));
l1=zeros(1,size(A,1));
h1=zeros(1,size(A,1));
k2=zeros(1,size(A,1));
l2=zeros(1,size(A,1));
h2=zeros(1,size(A,1));

for t=1:TimeStep
        if t==1
            State(t,:)=Sta(t,:);
        else
            %模拟每个用户节点的状态
            for j=1:M
                %判断用户节点处于什么状态，然后根据其状态确定其转变情况
                if State(t-1,j)==0                          %此时处于易感状态0，可能向潜伏期转移
%                     P_0_1=a1;                       %节点感染病毒的概率
                    for i=1:M
                        if A(i,j)==1
                          
                          k(i)=1;
                        end   
                        if State(t-1,i)==2 && k(i)==1
                          
                          l(i)=1;
                        end
                        if State(t-1,i)==3 && k(i)==1
                          
                          h(i)=1;
                        end
                    end                          %k 邻居节点

                    
                    prob(j)=1-(1-a1)^sum(l)*(1-a2)^sum(h);
                   
                    

                    if rand<=prob(j)                     %此时节点进入潜伏期
                       State(t,j)=1;
                    else
                       State(t,j)=State(t-1,j); 
                    end
                elseif State(t-1,j)==1         %此时处于潜伏状态E，可能向易感S，染病I和免疫R转移
                        r1=rand;
                        if r1<=p1                 %向染病状态I转移                
                            State(t,j)=2;
                                      
                        elseif r1<=p1+p2&&r1>p1           %向易感状态S转移           
                                State(t,j)=3;
                        elseif rand<v
                                State(t,j)=4;
                        else
                                State(t,j)=State(t-1,j);       %状态不变，依然为潜伏期E（1）
                        end
                elseif State(t-1,j)==2
                       r2=rand;
                       for i=1:M
                          if A(i,j)==1
                          
                             k1(i)=1;
                          end   
                          if State(t-1,i)==3 && k1(i)==1
                          
                             l1(i)=1;
                          end
                          if State(t-1,i)==4 && k1(i)==1
                          
                             h1(i)=1;
                          end
                       end                          %k 邻居节点

                    
                       prob1(j)=1-(1-t1)^sum(l1)*(1-b1)^sum(h1)-t1;


                        if r2<=t1                 %向染病状态I转移                
                            State(t,j)=3;
                                      
                        elseif r2>t1&&r2<=prob1(j)           %向易感状态S转移           
                                State(t,j)=4;
                        else
                                State(t,j)=State(t-1,j);       %状态不变，依然为潜伏期E（1）
                        end

                elseif State(t-1,j)==3
                       r3=rand;
                       for i=1:M
                          if A(i,j)==1
                          
                             k2(i)=1;
                          end   
                          if State(t-1,i)==2 && k2(i)==1
                          
                             l2(i)=1;
                          end
                          if State(t-1,i)==4 && k2(i)==1
                          
                             h2(i)=1;
                          end
                       end                          %k 邻居节点

                       prob2(j)=1-(1-t2)^sum(l2)*(1-b2)^sum(h2)-t2;

                        if r3<=t2                 %向染病状态I转移                
                            State(t,j)=2;
                                      
                        elseif r3>t2&&r3<=prob2(j)           %向易感状态S转移           
                                State(t,j)=4;
                        else
                                State(t,j)=State(t-1,j);       %状态不变，依然为潜伏期E（1）
                        end

                elseif State(t-1,j)==4
                        State(t,j)=State(t-1,j);
                end
            end
        end
        
        %统计各状态的节点数量
        Number_State(1,t)=sum(State(t,:)==0);%处于易感状态S的总节点数量
        Number_State(2,t)=sum(State(t,:)==1);%处于易感状态E的总节点数量
        Number_State(3,t)=sum(State(t,:)==2);%处于易感状态I的总节点数量
        Number_State(4,t)=sum(State(t,:)==3);%处于易感状态R的总节点数量
        Number_State(5,t)=sum(State(t,:)==4);
end

Infected=max(Number_State(3,:)+Number_State(4,:));
end
