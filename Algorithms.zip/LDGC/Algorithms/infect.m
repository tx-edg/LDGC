% p=plot(infectednode');
% p(1).Marker = '+';
% p(2).Marker = '*';
% p(3).Marker = 's';
% p(4).Marker = 'd';
% p(5).Marker = 'h';
% p(6).Marker = 'p';
% xlabel('T');
% ylabel('Infected nodes');
% B=0;
% Data=load("data aves-wildbird-network.txt");
% 
%     for j=1:113
%        
%            ii=find(Data(:,1)==j);
%            A=unique(Data(ii,2));
%            AA=length(A);
%            B=B+AA;
%        
%     end

B=unique(A(:,2));

C=length(B)