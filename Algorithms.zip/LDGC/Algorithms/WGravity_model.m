function WGC = WGravity_model(A)
G_GC=graph(A);
deg_GC=centrality(G_GC,"degree")';
[x,y]=eig(A);
lambda=diag(y);
[lambda_max,ii]=max(lambda);
ei=x(:,ii);
Norei=mapminmax(abs(ei),0,1);
D_GC=dis(A);
ecc = max(D_GC.*(D_GC~=Inf),[],2);
r = min(ecc);
WGC=zeros(1,size(A,1));
WGH=zeros(size(A,1),size(A,1));
for k=1:size(A,1)
 for d=1:r
  i=D_GC(k,:)==d;
  WGH(k,d)=(1/power(d,2))*deg_GC(1,k)*sum(deg_GC(1,i));
 end
end
GC=sum(WGH');
for i=1:size(A,1)
WGC(1,i)=Norei(i,1)*GC(1,i);
end