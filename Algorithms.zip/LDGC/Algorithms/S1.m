function Inf = S1(A,a1,TimeStep)

Inf=zeros(1,size(A,1));
for g=1:size(A,1)
  r1=0.001;
  M=size(A,1);
  Sta=zeros(TimeStep,M);
  prob=zeros(1,size(A,1));
  Number_State=zeros(3,TimeStep);
  Sta(1,g)=1;
  k=zeros(1,size(A,1));
  l=zeros(1,size(A,1));
  for t=1:TimeStep
        if t==1
            State(t,:)=Sta(t,:);
        else
            %模拟每个用户节点的状态
            for j=1:M
                %判断用户节点处于什么状态，然后根据其状态确定其转变情况
                if State(t-1,j)==0                          %此时处于易感状态0，可能向潜伏期转移
                    for i=1:M
                        if A(i,j)==1
                          
                          k(i)=1;
                        end   
                        if State(t-1,i)==1 && k(i)==1
                          
                          l(i)=1;
                        end
                        
                    end                          %k 邻居节点

                    
                    prob(1,j)=1-(1-a1)^sum(l);
                    if rand<=prob(1,j)                    %此时节点进入潜伏期
                       State(t,j)=1;
                    else
                       State(t,j)=State(t-1,j); 
                    end
                elseif State(t-1,j)==1         %此时处于潜伏状态E，可能向易感S，染病I和免疫R转移
                        if r1<=1                 %向染病状态I转移                
                            State(t,j)=2;
                        end
                elseif State(t-1,j)==2
                       State(t,j)=State(t-1,j);       
                end
                
        end
        end
        %统计各状态的节点数量
        Number_State(1,t)=sum(State(t,:)==0);%处于易感状态S的总节点数量
        Number_State(2,t)=sum(State(t,:)==1);%处于易感状态E的总节点数量
        Number_State(3,t)=sum(State(t,:)==2);

   end

   Inf(1,g)=sum(Number_State(2,:));

end
end