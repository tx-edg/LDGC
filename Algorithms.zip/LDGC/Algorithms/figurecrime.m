% bt=0.01:0.01:0.1;
% figure
% p=plot(bt,TAU(:,1),bt,TAU(:,2),bt,TAU(:,3),bt,TAU(:,4),bt,TAU(:,5),bt,TAU(:,6),bt,TAU(:,7),bt,TAU(:,8),bt,TAU(:,9),bt,TAU(:,10));
% 
% p(1).LineWidth = 1;
% p(2).LineWidth = 1;
% p(3).LineWidth = 1;
% p(4).LineWidth = 1;
% p(5).LineWidth = 1;
% p(6).LineWidth = 1;
% p(7).LineWidth = 1;
% p(8).LineWidth = 1;
% p(9).LineWidth = 1;
% p(10).LineWidth = 1;
% 
% axis([0.01 0.1 0 0.4])
% 
% legend('DC','BC','CC','HC','EC','GC','WGC','GGC','EGC','LGC');
% p(1).Marker = '+';
% p(2).Marker = '*';
% p(3).Marker = 'x';
% p(4).Marker = 'd';
% p(5).Marker = 'h';
% p(6).Marker = 'p';
% p(7).Marker = 'square';
% p(8).Marker = 'diamond';
% p(9).Marker = 'v';
% p(10).Marker = 's';

% bt=0.05:0.05:0.5;
% figure
% p=plot(bt,TAU(:,1),bt,TAU(:,2),bt,TAU(:,3),bt,TAU(:,4),bt,TAU(:,5),bt,TAU(:,6),bt,TAU(:,7),bt,TAU(:,8),bt,TAU(:,9),bt,TAU(:,10));
% 
% p(1).LineWidth = 1;
% p(2).LineWidth = 1;
% p(3).LineWidth = 1;
% p(4).LineWidth = 1;
% p(5).LineWidth = 1;
% p(6).LineWidth = 1;
% p(7).LineWidth = 1;
% p(8).LineWidth = 1;
% p(9).LineWidth = 1;
% p(10).LineWidth = 1;
% 
% axis([0.05 0.5 0 0.4])
% 
% legend('DC','BC','CC','HC','EC','GC','WGC','GGC','EGC','LGC');
% p(1).Marker = '+';
% p(2).Marker = '*';
% p(3).Marker = 'x';
% p(4).Marker = 'd';
% p(5).Marker = 'h';
% p(6).Marker = 'p';
% p(7).Marker = 'square';
% p(8).Marker = 'diamond';
% p(9).Marker = 'v';
% p(10).Marker = 's';

% bt=0.02:0.02:0.2;
% figure
% p=plot(bt,TAU(:,1),bt,TAU(:,2),bt,TAU(:,3),bt,TAU(:,4),bt,TAU(:,5),bt,TAU(:,6),bt,TAU(:,7),bt,TAU(:,8),bt,TAU(:,9),bt,TAU(:,10));
% 
% p(1).LineWidth = 1;
% p(2).LineWidth = 1;
% p(3).LineWidth = 1;
% p(4).LineWidth = 1;
% p(5).LineWidth = 1;
% p(6).LineWidth = 1;
% p(7).LineWidth = 1;
% p(8).LineWidth = 1;
% p(9).LineWidth = 1;
% p(10).LineWidth = 1;
% 
% axis([0.02 0.2 0 0.4])
% 
% legend('DC','BC','CC','HC','EC','GC','WGC','GGC','EGC','LGC');
% p(1).Marker = '+';
% p(2).Marker = '*';
% p(3).Marker = 'x';
% p(4).Marker = 'd';
% p(5).Marker = 'h';
% p(6).Marker = 'p';
% p(7).Marker = 'square';
% p(8).Marker = 'diamond';
% p(9).Marker = 'v';
% p(10).Marker = 's';

% bt=0.05:0.05:0.5;
% figure
% p=plot(bt,TAU(:,1),bt,TAU(:,2),bt,TAU(:,3),bt,TAU(:,4),bt,TAU(:,5),bt,TAU(:,6),bt,TAU(:,7),bt,TAU(:,8),bt,TAU(:,9),bt,TAU(:,10));
% 
% p(1).LineWidth = 1;
% p(2).LineWidth = 1;
% p(3).LineWidth = 1;
% p(4).LineWidth = 1;
% p(5).LineWidth = 1;
% p(6).LineWidth = 1;
% p(7).LineWidth = 1;
% p(8).LineWidth = 1;
% p(9).LineWidth = 1;
% p(10).LineWidth = 1;
% 
% axis([0.05 0.5 0 0.4])
% 
% legend('DC','BC','CC','HC','EC','GC','WGC','GGC','EGC','LGC');
% p(1).Marker = '+';
% p(2).Marker = '*';
% p(3).Marker = 'x';
% p(4).Marker = 'd';
% p(5).Marker = 'h';
% p(6).Marker = 'p';
% p(7).Marker = 'square';
% p(8).Marker = 'diamond';
% p(9).Marker = 'v';
% p(10).Marker = 's';

% bt=0.01:0.01:0.1;
% figure
% p=plot(bt,TAU(:,1),bt,TAU(:,2),bt,TAU(:,3),bt,TAU(:,4),bt,TAU(:,5),bt,TAU(:,6),bt,TAU(:,7),bt,TAU(:,8),bt,TAU(:,9),bt,TAU(:,10));
% 
% p(1).LineWidth = 1;
% p(2).LineWidth = 1;
% p(3).LineWidth = 1;
% p(4).LineWidth = 1;
% p(5).LineWidth = 1;
% p(6).LineWidth = 1;
% p(7).LineWidth = 1;
% p(8).LineWidth = 1;
% p(9).LineWidth = 1;
% p(10).LineWidth = 1;
% 
% axis([0.01 0.1 0 0.4])
% 
% legend('DC','BC','CC','HC','EC','GC','WGC','GGC','EGC','LGC');
% p(1).Marker = '+';
% p(2).Marker = '*';
% p(3).Marker = 'x';
% p(4).Marker = 'd';
% p(5).Marker = 'h';
% p(6).Marker = 'p';
% p(7).Marker = 'square';
% p(8).Marker = 'diamond';
% p(9).Marker = 'v';
% p(10).Marker = 's';


% bar(SELHR);
% 
% ylabel("Infected Nodes")
% legend('DC','BC','CC','HC','EC','LGC')


% bt=0.005:0.005:0.05;
% figure
% p=plot(bt,TAU(:,1),bt,TAU(:,2),bt,TAU(:,3),bt,TAU(:,4),bt,TAU(:,5),bt,TAU(:,6),bt,TAU(:,7),bt,TAU(:,8),bt,TAU(:,9),bt,TAU(:,10));
% 
% p(1).LineWidth = 1;
% p(2).LineWidth = 1;
% p(3).LineWidth = 1;
% p(4).LineWidth = 1;
% p(5).LineWidth = 1;
% p(6).LineWidth = 1;
% p(7).LineWidth = 1;
% p(8).LineWidth = 1;
% p(9).LineWidth = 1;
% p(10).LineWidth = 1;
% 
% axis([0.005 0.05 0 0.3])
% 
% legend('DC','BC','CC','HC','EC','GC','WGC','GGC','EGC','LGC');
% p(1).Marker = '+';
% p(2).Marker = '*';
% p(3).Marker = 'x';
% p(4).Marker = 'd';
% p(5).Marker = 'h';
% p(6).Marker = 'p';
% p(7).Marker = 'square';
% p(8).Marker = 'diamond';
% p(9).Marker = 'v';
% p(10).Marker = 's';


bt=0.01:0.01:0.1;
figure
p=plot(bt,TAU(:,1),bt,TAU(:,2),bt,TAU(:,3),bt,TAU(:,4),bt,TAU(:,5),bt,TAU(:,6),bt,TAU(:,7),bt,TAU(:,8),bt,TAU(:,9),bt,TAU(:,10));

p(1).LineWidth = 1;
p(2).LineWidth = 1;
p(3).LineWidth = 1;
p(4).LineWidth = 1;
p(5).LineWidth = 1;
p(6).LineWidth = 1;
p(7).LineWidth = 1;
p(8).LineWidth = 1;
p(9).LineWidth = 1;
p(10).LineWidth = 1;

axis([0.01 0.1 0 0.4])

legend('DC','BC','CC','HC','EC','GC','WGC','GGC','EGC','LGC');
p(1).Marker = '+';
p(2).Marker = '*';
p(3).Marker = 'x';
p(4).Marker = 'd';
p(5).Marker = 'h';
p(6).Marker = 'p';
p(7).Marker = 'square';
p(8).Marker = 'diamond';
p(9).Marker = 'v';
p(10).Marker = 's';