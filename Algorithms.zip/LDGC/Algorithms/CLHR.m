tic
Data=load("data aves-wildbird-network.txt");
m=max(max(Data));
C=zeros(m);
for kadj=1:size(Data,1)
  for i=1:size(C,1)
    for j=1:size(C,2)
          if i==Data(kadj,1)&&j==Data(kadj,2)
           C(i,j)=1;
           C(j,i)=1;
          end
     end
  end
end
A=C;

Infected=zeros(2,10);

for i=1:10
    ii=topa(i,:);
    Infected(1,i)=LHR(A,ii);
end

for i=1:10
    is=topa(i,[1,2,3,4,5]);
    iss=topa(i,[6,7,8,9,10]);
    Infected(2,i)=LHR2(A,is,iss);
end


