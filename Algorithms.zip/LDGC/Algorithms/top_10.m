clear;
%Network
Data=load("data insecta-ant-colony1.txt");
m=max(max(Data));
C=zeros(m);
for kadj=1:size(Data,1)
  for i=1:size(C,1)
    for j=1:size(C,2)
          if i==Data(kadj,1)&&j==Data(kadj,2)
           C(i,j)=1;
           C(j,i)=1;
          end
     end
  end
end
A=C;
B=zeros(size(A,1));

Graph_DC=graph(A);
Deg_C = centrality(Graph_DC,"degree");

Graph_BC=graph(A);
Betweenness_C = centrality(Graph_BC,"betweenness");

Graph_CC=graph(A);
Closeness_C = centrality(Graph_CC,"closeness");

Graph_EC=graph(A);
Eigen_C = centrality(Graph_CC,"eigenvector");

HC = H_index(A);

GC = Gravity_model(A);

WGC = Gravity_model(A);

GGC = Gravity_model(A);

EGC = Gravity_model(A);

LGC = Gravity_model(A);

[a1,B(:,1)]=sort(Deg_C,'descend');

[a2,B(:,2)]=sort(Betweenness_C,'descend');

[a3,B(:,3)]=sort(Closeness_C,'descend');

[a4,B(:,4)]=sort(HC,'descend');

[a5,B(:,5)]=sort(Eigen_C,'descend');

[a6,B(:,6)]=sort(GC,'descend');

[a7,B(:,7)]=sort(WGC,'descend');

[a8,B(:,8)]=sort(GGC,'descend');

[a9,B(:,9)]=sort(EGC,'descend');

[a10,B(:,10)]=sort(LGC,'descend');
