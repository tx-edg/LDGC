function LGC = LGravity_model(A)

Graph_DC=graph(A);
Deg_C = centrality(Graph_DC,"degree");

LGHC= H_index(A)';
L=zeros(1,size(A,1));
LGH=zeros(size(A,1),size(A,1));
cw=zeros(1,size(A,1));

L=(LGH+Deg_C)/2;

D_LGC=dis(A);
r=round(max(D_LGC)/2);
for k=1:size(A,1)
 for d=1:r(1,k)
  i=D_LGC(k,:)==d;
  LGH(k,d)=(1/power(d,2))*L(1,k)*sum(L(1,i));
 end
end

for r=1:max(r)
    cw(r)=exp(1-r);
end

pp=LGH.*cw;
LGC=sum(pp,2);


