clear;
%Network
Data=load("data insecta-ant-colony1.txt");
m=max(max(Data));
C=zeros(m);
for kadj=1:size(Data,1)
  for i=1:size(C,1)
    for j=1:size(C,2)
          if i==Data(kadj,1)&&j==Data(kadj,2)
           C(i,j)=1;
           C(j,i)=1;
          end
     end
  end
end
A=C;


% SIR Simulation 

for k=1:size(A,1)
num_of_steps = 200; %maximum number of iterations. If all the nodes get recovered before that, the simulation will stop
prob = 0.0092; %the probability that the node will be infected from already infected neighboring node
r = 1; %the recovery rate
parent_node = k; %the ID of the node where infection starts. If parent_node is an array of IDs,
%the infection will start in all of the nodes listed in parent_node. For
%example: parent_node = [1 5 7] means the infection will start in nodes 1 5 and 7 
immunized = 0.0092; %the custom probability of virus transmission to certain nodes could be specified if needed.

%For custom transmission probabilities, the vector "immunized" should have the size of number of nodes where
%each entry is the customized probability of transmission to certain node. If left empty, the p is the same
%for all nodes. For example, if network has 5 nodes and we want to
%customize the probabilities of transmission, then immunized vector should
%have the following form: immunized = [0.5 0.5 0.7 0.5 0.9]

%Start of the simulation
[inf,nisum,rec,infsum] = sir_simulation(A,parent_node,prob,immunized,r,num_of_steps);
%simulation rank
Color(k)=infsum(1,end);
R(k)=rec(1,end);
end

Graph_DC=graph(A);
Deg_C = centrality(Graph_DC,"degree");

Graph_BC=graph(A);
Betweenness_C = centrality(Graph_BC,"betweenness");

Graph_CC=graph(A);
Closeness_C = centrality(Graph_CC,"closeness");

HC = H_index(A);

Graph_EC=graph(A);
Eigen_C = centrality(Graph_CC,"eigenvector");

GC = Gravity_model(A);

WGC = WGravity_model(A);

GGC = GGravity_model(A);

EGC = EGravity_model(A);

LGC = LGravity_model(A);

figure 
c = Color;
scatter(LGC/max(LGC),HC/max(HC),15,c,'filled');
xlabel('LGC');
ylabel('HC');

figure 
c = Color;
scatter(LGC/max(LGC),Eigen_C/max(Eigen_C),15,c,'filled');
xlabel('LGC');
ylabel('EC');

figure 
c = Color;
scatter(LGC/max(LGC),GC/max(GC),15,c,'filled');
xlabel('LGC');
ylabel('GC');

figure 
c = Color;
scatter(LGC/max(LGC),WGC/max(WGC),15,c,'filled');
xlabel('LGC');
ylabel('WGC');

figure 
c = Color;
scatter(LGC/max(LGC),GGC/max(GGC),15,c,'filled');
xlabel('LGC');
ylabel('GGC');

figure 
c = Color;
scatter(LGC/max(LGC),EGC/max(EGC),15,c,'filled');
xlabel('LGC');
ylabel('EGC');


