Data=load("data econ-wm3.txt");
m=max(max(Data));
C=zeros(m);
for kadj=1:size(Data,1)
  for i=1:size(C,1)
    for j=1:size(C,2)
          if i==Data(kadj,1)&&j==Data(kadj,2)
           C(i,j)=1;
           C(j,i)=1;
          end
     end
  end
end
A=C;
G=graph(A);
DC= centrality(G,'degree');
d=sum(DC)/size(A,1);
de=DC.'*DC/size(A,1);
bt=d/de;