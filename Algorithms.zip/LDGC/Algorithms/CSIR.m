clear;
%Network
Data=load("data insecta-ant-colony1.txt");
m=max(max(Data));
C=zeros(m);
for kadj=1:size(Data,1)
  for i=1:size(C,1)
    for j=1:size(C,2)
          if i==Data(kadj,1)&&j==Data(kadj,2)
           C(i,j)=1;
           C(j,i)=1;
          end
     end
  end
end
A=C;


% SIR Simulatio

for k=1:size(A,1)
num_of_steps = 50; %maximum number of iterations. If all the nodes get recovered before that, the simulation will stop
prob = 0.05; %the probability that the node will be infected from already infected neighboring node
r = 1; %the recovery rate
parent_node = k; %the ID of the node where infection starts. If parent_node is an array of IDs,
immunized = 0.0092; %the custom probability of virus transmission to certain nodes could be specified if needed.
[inf,nisum,rec,infsum] = sir_simulation(A,parent_node,prob,immunized,r,num_of_steps);
Color(k)=infsum(1,end);
R(k)=rec(1,end);
end


% TimeStep = 3;
% a1 = 0.1; 
% 
% Inf = S1(A,a1,TimeStep);
% R=Inf;


H_tau_error=zeros(1,10);
%Deg
Graph_DC=graph(A);
Deg_C = centrality(Graph_DC,"degree");

%DCtao
H_tau_error(1,1)=fkendall(R',Deg_C);


%BC
Graph_BC=graph(A);
Betweenness_C = centrality(Graph_BC,"betweenness");
%BCtao
H_tau_error(1,2)=fkendall(R',Betweenness_C);


%CC 
Graph_CC=graph(A);
Closeness_C = centrality(Graph_CC,"closeness");
%tao
H_tau_error(1,3)=fkendall(R',Closeness_C);

%HC 
HC = H_index(A);
%tao
H_tau_error(1,4)=fkendall(R',HC);
% EC
Graph_EC=graph(A);
Eigen_C = centrality(Graph_CC,"eigenvector");
%tao
H_tau_error(1,5)=fkendall(R',Eigen_C);



%GC
GC = Gravity_model(A);
%tao
H_tau_error(1,6)=fkendall(R',GC);


%WGC
WGC = WGravity_model(A);
%tao
H_tau_error(1,7)=fkendall(R',WGC');


%GGC
GGC = GGravity_model(A);
%tao
H_tau_error(1,8)=fkendall(R',GGC');


%EGC
EGC = EGravity_model(A);
%tao
H_tau_error(1,9)=fkendall(R',EGC);


%LGC
LGC = LGravity_model(A);
%tao
H_tau_error(1,10)=fkendall(R',LGC);

H_tau_error