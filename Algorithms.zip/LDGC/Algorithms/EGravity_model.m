function EGC = EGravity_model(A)
D_EGC=dis(A);
d=max(D_EGC);
G_EGC=graph(A);
deg_EGC=centrality(G_EGC,"degree");
kmax=zeros(size(A,1),1);
R=zeros(size(A,1),1);
p=zeros(size(A,1),1);
V=zeros(size(A,1),1);
I=zeros(size(A,1),1);
EGH=zeros(size(A,1),size(A,1));
for k=1:size(A,1)
  i=find(D_EGC(k,:)==d(k));
  s=length(i);
  kmax(k)=sum(deg_EGC(i))/s;
  R(k)=round(d(k)/(1+sqrt(kmax(k)/deg_EGC(k))));
end

for k=1:size(A,1)
    i=find(A(k,:)==1);
    p(k)=deg_EGC(k)/sum(deg_EGC(i));
    
end
for i=1:size(A,1)
  I(i)=-sum(p(i)*log(p(i)));
end

for k=1:size(A,1)
  V(k)=I(k)*deg_EGC(k);
end

for k=1:size(A,1)
 for d=1:R
  i=D_EGC(k,:)==d;
  EGH(k,d)=(1/power(d,2))*V(k)*sum(V(i));
 end
end
EGC=sum(EGH')';
end