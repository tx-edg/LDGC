function GGC = GGravity_model(A)
n=length(A);
Co=zeros(n,1);
sp=zeros(n,1);
nv=zeros(n,1);
G_GGC=graph(A);
GGH=zeros(size(A,1),size(A,1));
deg_GGC=centrality(G_GGC,"degree")';

for k=1:size(A,1)
  nei=find(A(k,:)==1);
  for i=1:length(nei)
      for j=1:length(nei)
       if A(nei(i),nei(j))==1
        nv(k,1)=nv(k,1)+1;
       end
      end
  end
end
for k=1:size(A,1)
    if deg_GGC(1,k)>1
    Co(k,1)=nv(k,1)/(deg_GGC(1,k)*(deg_GGC(1,k)-1));
    end
end
for k=1:size(A,1)
    sp(k,1)=exp(-2*Co(k,1))*deg_GGC(1,k);
end
D_GC=dis(A);
ecc = max(D_GC.*(D_GC~=Inf),[],2);
r = min(ecc);
for k=1:size(A,1)
 for d=1:r
  i=D_GC(k,:)==d;
  GGH(k,d)=(1/power(d,2))*sp(k,1)*sum(sp(i,1));
 end
end
GGC=sum(GGH');





