function GC = Gravity_model(A)
G_GC=graph(A);
deg_GC=centrality(G_GC,"degree")';
D_GC=dis(A);
GH=zeros(size(A,1));
ecc = max(D_GC.*(D_GC~=Inf),[],2);
r = min(ecc);
for k=1:size(A,1)
 for d=1:r
  i=D_GC(k,:)==d;
  GH(k,d)=(1/power(d,2))*deg_GC(1,k)*sum(deg_GC(1,i));
 end
end
GC=sum(GH')';