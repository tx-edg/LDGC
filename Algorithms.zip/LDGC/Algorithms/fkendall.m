function H_tau_error = fkendall(U3,H)

max_U3 = max(abs(U3));
U3 = U3./max_U3;

max_H = max(abs(H));
H = H./max_H;



%Kendall's tau
T_huy = zeros(size(U3,1),size(U3,1));
for ver = 1:size(T_huy,1)
    for hor = ver:size(T_huy,2)
        T_huy(ver,hor) = sign(abs(U3(ver,1))-abs(U3(hor,1)));
    end
end
%calculate tau
discordance = 0;
concordance = 0;
T_hyb = zeros(size(U3,1),size(U3,1));
for ver = 1:size(T_hyb,1)
    for hor = ver:size(T_hyb,2)
        T_hyb(ver,hor) = sign(abs(H(ver,1))-abs(H(hor,1)));
        D = abs(T_huy(ver,hor)-T_hyb(ver,hor));
        C = abs(T_huy(ver,hor)+T_hyb(ver,hor));
        if D ==2
            discordance = discordance+1;
        elseif C ==2
            concordance = concordance+1;
        end
    end
end
H_tau_error =2*(concordance-discordance)/(size(H,1)*(size(H,1)-1));


end