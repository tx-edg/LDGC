for i=1:2
	%打开的fig文件酌情修改路径
    hf(i)=open([num2str(i),'.fig']);%打开fig
    fig(i)=get(hf(i), 'CurrentAxes');%获取绘制的图像
end
%新建一个图窗
figure

for i=1:2
	%看要绘制多少行多少列酌情改变
    subplot(2,3,i);%第i个子图
    axChildren = get(fig(i),'Children');%获取绘制的图像
    copyobj(axChildren, gca);%复制到当前图窗里
   close(hf(i));%关掉已经复制的图像

    %下面是对图片进行设置，请酌情修改
%     title(['S曲线第',num2str(i),'次测试']);%绘制子图标题
%     xlabel('Angle(\circ)');%绘制子图x标签
%     ylabel('Center WaveLength Change(nm)');%绘制子图y标签
%     yaxis([-0.05,0.2])%绘制子图y的范围
%     xticks([0 20 40 60 80 100]);%绘制子图刻度
end
set(gcf,'unit','centimeters','position',[32 15 32 15]);
